This cooling fan assembly is very well suited for cooling your parts.
It consists of:
1x Part1 - E3D_DoubleDuct.stl
2x Part2 - Duct_30mm.stl
2x 30mm fan

You can choose to use only one duct and 1 fan. That is ok but it will only cool on one side.
It is also possible to use 40mm fans. They have even more cooling power but are bigger and heavier.
This fan assembly will provide more than enough cooling. In fact it can work too well sometimes.
If set to full with 2 fans it can cause the hotend temp to drop. Keep that in mind. Setting it to a 50% duty cycle is usually more than enough.